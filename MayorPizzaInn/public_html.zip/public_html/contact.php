    <?php include('partials-front/menu.php'); ?>
    
    
    
      
     
    
    <section class="contact-form">
        <div class="container">
            <h2 class="text-center">CONTACT US</h2>
            <form action="contactform.php" method="POST" class="text-center">
               <input type="text" name="name" placeholder="Full Name" required class="input-responsive ">
                <input type="email" name="email" placeholder="Your e-mail" required class="input-responsive ">
                <input type="text" name="subject" placeholder="Subject" required class="input-responsive ">
                <input type="text" name="subject" placeholder=" Add Your Email && Other Details To Get FeedBack " required class="input-responsive ">
                <textarea name="message" placeholder="Your Message" required class="input-responsive "></textarea>
                <button type="submit" name="submit" class="btn btn-primary">SEND MAIL</button>
            </form>
    
        </div>
    </section>
    
    
    
    <?php include('partials-front/footer.php');  ?>