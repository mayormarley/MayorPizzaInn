    <?php
    
    
    // Create constants to store non-repeating values
    define('SITEURL', 'https://mayorpizzain.000webhostapp.com/');
    define('LOCALHOST', 'localhost');
    define('DB_USERNAME', 'id21481332_if0_34825076');
    define('DB_PASSWORD', '0559234363Marley@');
    define('DB_NAME', 'id21481332_mayoroperation');
    
    // Database Connection
    $conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD, DB_NAME, 3306); // Check the port number if it's correct
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    // Selecting Database
    $db_select = mysqli_select_db($conn, DB_NAME);
    
    if (!$db_select) {
        die("Database selection failed: " . mysqli_error($conn));
    }
    // Start Session
    session_start();
    ?>
