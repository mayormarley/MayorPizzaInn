<?php include("partials/menu.php"); ?>


<?php


    //Check whether the id is set or Not
   if(isset($_GET['id']))
     {
       //Get the ID and all other details
       //echo "Getting  the Data";
        $id = $_GET['id'];


        //Create SQL Query to get all other details
        $sql2 = "SELECT * FROM tbl_food WHERE id=$id";

        //Execute the Query
        $res2 = mysqli_query($conn, $sql2 );

        // Count the Rows check whether the id is valid or not 
       //  $count = mysqli_num_rows($res2);


          //Get all the data
          $row2 = mysqli_fetch_assoc($res2);

          //Get individual values of Selected Food 
          $title = $row2['title'];
          $description = $row2['description'];
          $price = $row2['price'];
          $current_image = $row2['image_name'];
          $current_category = $row2['category_id'];
          $featured = $row2['featured'];
          $active = $row2['active'];
     
     }
     else
     {
       //REdirect to Manage Food
        header("location:".SITEURL.'admin/manage-food.php');
     }
    
  

?>







  <div class="main-content">
    <div class="wrapper">
      <h1>Update Food</h1>
       <br><br>


                 <!----Add Food Form Start-->

    <form action="" method="POST" enctype="multipart/form-data">

    <table class="tbl-30">

    <tr>
      <td>Title: </td>
      <td>
        <input type="text" name="title" value="<?php echo $title; ?>" >
      </td>
    </tr>

    <tr>
      <td>Description:</td>
      <td>
        <textarea name="description"  cols="30" rows="5" ><?php echo $description; ?></textarea>
      </td>
    </tr>


    <tr>
  <td>Price: </td>
  <td>
    <input type="number" name="price" value="<?php echo $price; ?>">
  </td>
   </tr>




      <tr>
        <td>Current Image: </td>
        <td>
         <?php
         
          if($current_image == "")
          {


             // Image not Available
             echo '<div class="error">Image not Available';

          }
          else
          {
             // Image Available
               
               ?>
           <img src="<?php  echo SITEURL; ?>images/food/<?php echo $current_image; ?>" width="150px">
                <?php
          }
         
         
         
         
         ?>
        </td>
      </tr>



    <tr>
      <td>Select New Image: </td>
      <td>
        <input type="file" name="image" >
      </td>
    </tr>




    <tr>
      <td>Category:</td>
      <td>
        <select name="category" >


        <?php
        
        // Craete PHP Code to display categories from Database
        //1. Create SQl to get all active  categories from database 
        $sql ="SELECT * FROM tbl_category WHERE active='Yes'";
        
        // Executing Query
        $res = mysqli_query($conn, $sql);


        //Count Rows to Check whether we have categories or Not 
        $count = mysqli_num_rows($res);


        //IF count is greater than zero, we have categories else we do not have categories 
        if($count>0)
        {

          //Get the details of categories 
          while($row=mysqli_fetch_assoc($res))
          {
            //get the details of categories 
            $category_id = $row['id'];
            $category_title = $row['title'];

           echo "<option value='$category_id';>$category_title </option>";
            

          }
        }
        else
        {
           //we do not have category
          
          // echo '<option value="0">category Not Available . </option>';
            ?>
              <option  <?php  if($current_category==$category_id){ echo "Selected";} ?>   value="<?php   echo $category_id;  ?>" ><?php  echo $category_title; ?></option>
            <?php

           
           
        }

        
        ?>
         
        </select>
      </td>
    </tr>

       

        
       <tr>
        <td>Featured: </td>
        <td>
          <input   <?php if($featured=="yes"){echo "checked";}?> type="radio" name="featured" value="yes">Yes

          <input <?php if($featured=="no"){echo "checked";}?>  type="radio" name="featured" value="no">No
        </td>
       </tr>


            <tr>
               <td>Active: </td>
                 <td>
                <input <?php if ($active == "yes") { echo "checked"; } ?> type="radio" name="active" value="yes">Yes


                <input <?php if ($active == "no") { echo "checked"; } ?> type="radio" name="active" value="no">No
                </td>
             </tr>


             <tr>
              <td colspan="2">
                     <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
                     <input type="hidden" name="id" value="<?php echo $id; ?>">

                    <input type="submit"  name="submit" value="Update Food" class="btn-secondary">
              </td>
             </tr>

    </table>
    </form>

      <!----Add Food Form Ends -->


    <?php
    
      if(isset($_POST['submit']))
{
    


        
      // echo clicked 
         //1. Get all the values from our form
         $id  = $_POST['id'];
         $title = $_POST['title'];
         $description = $_POST['description'];
         $price = $_POST['price'];
         $current_image = $_POST['current_image'];
         $category = $_POST['category'];

         $featured = $_POST['featured'];
         $active = $_POST['active'];



              // 2. Updating New Image if Selected 
         // Check whether  the image is selected or Not 
         if(isset($_FILES['image']['name']))
         {
           //Get the Image Detail
           $image_name = $_FILES['image']['name']; //New Image Name 


             // Check Whether the Image is Available or Not 
           if($image_name != "")
           {
            //Image Available
            //A. Upload the New Image

               //Auto Rename Our Image
              // Get the Extension of our Image (jpg, png, gif, etc)eg. "specialfood1.jpg"
              $exploded_name = explode('.', $image_name);
               $ext = end($exploded_name);


               //Rename the Image
               $image_name = "Food-Name-".rand(000, 999).".".$ext; // eg. "Food_Category_834.jpg"

               
                  /// Get the source path and the Destination path 
            $source_path = $_FILES['image']['tmp_name'];

            $destination_path = "../images/food/".$image_name;

            // Finally Upload the Image
             $upload = move_uploaded_file($source_path, $destination_path);

                    //Check whether the image is uploaded or not 
                   // And if the image is not uploadedthen we will stop the process and Redirect with error 
                  if($upload==false)
                  {
                     //Set Message
                     $_SESSION['upload'] = '<div class="error">Failed To Upload New  Image.</div>';
                     // Redirect  to Add Category Page
                     header('location:'.SITEURL.'admin/manage-food.php');
                      //Stop the process
                     die();

                  }

                 //step 3. B. Remove the current Image if Available
            if($current_image!="")
            {
            $remove_path = "../images/food/".$current_image;

            $remove = unlink($remove_path);

            // Check Whether Image is Removed or not 
            // if failed tp remove then display message and stop the process 
            if($remove==false)
            {
               //Failed to remove image 
                 $_SESSION['remove-failed'] = '<div class="error">Failed To Remove Current  Image.</div>';
                     // Redirect  to 
                     header('location:'.SITEURL.'admin/manage-food.php');
                     // stop the process
                     die();
            }
          }

         }
         else
         {
           $image_name = $current_image; // Default Image when Image is not selected 
         }
        }
      else
      {
        $image_name = $current_image; // Default Image when button is not Clicked 
      }

       //4. Updating the Database 
      $sql3 = "UPDATE tbl_food SET 
         title = '$title',
         description = '$description',
         price = $price,
         image_name = '$image_name',
         category_id = '$category',
         featured = '$featured',
         active = '$active'
         WHERE id = $id";


        // Execute the Query
         $res3 = mysqli_query($conn, $sql3);

         //4. REdirect to manage Category with Message 
         //Check whether executed or Not 
         if($res3==true)
         {
           // Category  Update
               $_SESSION['update'] = '<div class="success">Food Updated Successfully.</div>';
               //REdirect 
               header("location:".SITEURL.'admin/manage-food.php');
         }
         else 
         {
            // Failed to Update Category 

               $_SESSION['update'] = '<div class="error">Failed To Update Food.</div>';
               //REdirect 
               header("location:".SITEURL.'admin/manage-food.php');
         }
        

    }
    
    ?>



    </div>
  </div>




<?php include("partials/footer.php"); ?>