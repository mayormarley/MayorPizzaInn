<?php
// delete-order.php
// include constants.php file
include('../config/constants.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete order from the database
    $sql = "DELETE FROM tbl_order WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Order deleted successfully
        $_SESSION['delete'] = '<div class="success">Order deleted successfully.</div>';
        header("location: manage-order.php");
        die();
    } else {
        // Failed to delete order
        $_SESSION['delete'] = '<div class="error">Failed to delete order.</div>';
        header("location: manage-order.php");
        die();
    }
} else {
    // Redirect if no order id is provided
    $_SESSION['delete'] = '<div class="error">Invalid order ID.</div>';
    header("location: manage-order.php");
    die();
}
?>
