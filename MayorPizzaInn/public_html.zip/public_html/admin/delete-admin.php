<?php

     // Include constants.php file here
     include('../config/constants.php');

   // 1. get the ID of Admin to be deleted 
   $id = $_GET['id'];

   //2. Create SQL Query to Delete Admin
   $sql = "DELETE FROM tbl_admin WHERE id=$id";

      // Execute the Query 
      $res = mysqli_query($conn, $sql);


      //Check whether the query executed successfully or Not

        if($res==TRUE)
       {
          //Query Executed Successully and Admin Deleted
         //  echo "Admin Deleted";
         // Create a  Session variable to Display Message 
 
 

         $_SESSION['delete'] = '<div class="success">Admin Deleted Successfully.</div>';
         // Redirect Page to Manage Admin

         header("location:".SITEURL.'admin/manage-admin.php'); 
       }
       else
       {

          // Failed to insert Data
         // echo "Failed to insert Data";
             // Create a  Session variable to Display Message 

         $_SESSION['delete'] = '<div class="error">Failed to Delete Admin. Try Again Later.</div>';
         // Redirect Page to Add Admin
         header("location:".SITEURL.'admin/manage-admin.php'); 
       }
   
   
    // Redirect to Manage Admin  page with message ( success/error)

?>
