 <!--- Footer Section Start---->
 <div class="footer">
      <div class="wrapper">
        <p class="text-center">2023 All right reserved, Food House. Developed By -<a href="#"> Mayor-marley</a></p>
      </div>
  </div>
  <!--- Footer Section Ends---->
</body>


</html>
