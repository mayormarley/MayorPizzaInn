<?php
 
 // AUthorization - Access Control
 // Check whether the user is logged in or Not
 if(!isset($_SESSION['user'])) //IF user session is not set
 {
   //User is not logged in 
   //REdirect to login page with message
   $_SESSION['no-login-message'] = '<div class="error text-center">Please login to access admin panel.</div>';
   //REdirect to login page
   header('location:'.SITEURL.'admin/login.php');
 }

?> 

